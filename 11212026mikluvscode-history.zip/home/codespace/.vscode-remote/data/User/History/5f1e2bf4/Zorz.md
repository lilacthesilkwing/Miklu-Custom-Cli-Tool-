Talk to Hacksune Miklu, a cli tool based on Hatsune Miku from Project Sekai: Colorful Stage!
Ask her about the 